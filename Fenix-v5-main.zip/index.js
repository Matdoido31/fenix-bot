let enviroment = require("./configs/environment")
enviroment()
let start = require("./src/services/process")
start.emit();
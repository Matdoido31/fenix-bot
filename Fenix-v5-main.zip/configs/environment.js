function enviroment (){
    let jsonToMap = require("../lib/helpers/jsonToMap")
    let pt_br = jsonToMap(require("../src/assets/translate_content/pt-br/basic.json"))
    let es_eu = jsonToMap(require("../src/assets/translate_content/es-eu/basic.json"))
    let en_us = jsonToMap(require("../src/assets/translate_content/en-us/basic.json"))
    let lengs = new Map().set('pt-br', pt_br).set('es-eu', es_eu).set('en-us', en_us)
    global.themes = require("./themes.json") //themes
    global.Discord = require('discord.js'); // discord 
    global.db = require("../database/connection") // prisma;
    let langfunc = async (clientid) => {
        let lang = await db.prisma.client.findUnique({ where: { DiscordBotId: clientid } });
        return lengs.get(lang.Language) || lengs.get("pt-br");
    }
    global.adminconfig = require("./config.json")
    global.Logger = require("../lib/utils/Logger")
    global.language = langfunc //language
}
module.exports = enviroment
```markdown
# Estrutura do Projeto
```
## Lista de Afazeres
[Aqui](/brainstorm/lista_de_afazeres.txt)

## Descrição dos diretórios

- `index.js`: O ponto de entrada do aplicativo. Aqui é onde o bot é iniciado.

- `brainstorm/`: Uma pasta para armazenar ideias e pensamentos relacionados ao projeto.

- `src/`: A pasta principal de serviço, onde o bot é executado.

  - `assets/`: Contém componentes externos utilizados no projeto.

    - `imgs/`: Diretório para armazenar imagens utilizadas no projeto.

    - `translate_content/`: Armazena as traduções para cada linguagem suportada pelo bot.

      - `es-eu/`: Traduções para espanhol (Espanha).

      - `en-us/`: Traduções para inglês (Estados Unidos).

      - `pt-br/`: Traduções para português (Brasil).

  - `api/`: Este diretório contém a configuração de um servidor Express para enviar informações do bot para o site e um servidor Undici para puxar informações do site.

  - `services/`: Contém a maior parte da lógica do bot.

- `lib/`: Pasta para armazenar labels, módulos, classes, funções e outras utilidades que podem ajudar no projeto.

  - `utils/`: Contém utilidades e funções gerais.

  - `vendor/`: Pasta para armazenar bibliotecas ou módulos de terceiros.

    - `helpers/`: Contém utilidades específicas de terceiros.

- `database/`: Contém arquivos relacionados ao banco de dados do projeto.

  - `connection.js`: O arquivo de índice para a configuração da conexão com o banco de dados.

- `configs/`: Armazena as configurações relacionadas à interface.

  - `config.json`: Um arquivo JSON contendo as configurações específicas do projeto.

  - `environment.js`: Um arquivo (talvez) relacionado a configurações de ambiente.

type EventCallback = (...args: any[]) => void;

class EE {
  constructor(fn: EventCallback, context?: any, once?: boolean);
}

class EventEmitter {
  constructor();

  on(event: string, fn: EventCallback, context?: any, once?: boolean): this;
  once(event: string, fn: EventCallback, context?: any): this;
  emit(event: string, ...args: any[]): boolean;
  removeListener(
    event: string,
    fn?: EventCallback,
    context?: any,
    once?: boolean,
  ): this;
  removeAllListeners(event?: string): this;
  listeners(event: string): EventCallback[];
  listenerCount(event: string): number;
}

export = { EventEmitter };

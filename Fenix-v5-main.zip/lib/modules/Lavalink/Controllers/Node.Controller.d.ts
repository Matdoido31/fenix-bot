import { wss_server } from "../Connections/wss.server";
import { Manager } from "./Manager.Controller";
import { Rest } from "./Rest.Controller";
interface _wss_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
    userId: string;
    Shards?: number;
    LavaName?: string;
}
interface _Player_Stats {
    players?: number;
    playingPlayers?: number;
    uptime?: number;
    memory?: {
        free: number;
        used: number;
        allocated: number;
        reservable: number;
    };
    cpu?: {
        cores: number;
        systemLoad: number;
        lavalinkLoad: number;
    };
    frameStats?: {
        sent: number;
        nulled: number;
        deficit: number;
    };
}
export declare class Node {
    nodeStatus: _Player_Stats | any;
    connected: boolean;
    readonly Manager: Manager;
    readonly Wss_server: wss_server;
    Rest: Rest | undefined;
    constructor(Manager: Manager, Options: _wss_server_params);
    authSocketIo(): void;
    ready(payload: any, Options: _wss_server_params): void;
    stats(payload: any): void;
}
export {};

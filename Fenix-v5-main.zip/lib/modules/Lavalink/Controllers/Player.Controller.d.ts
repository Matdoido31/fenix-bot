/// <reference types="node" />
import { EventEmitter } from "@fenixdbp/eventemitter";
import { Queue } from "./Queue.controller";
import { Node } from "./Node.Controller";
interface _Player_discord_params {
    guild: any;
    voiceChannel: any;
    textChannel: any;
    voiceState?: any;
    options: {
        selfMute: boolean;
        selfDeaf: boolean;
    };
}
interface _Player_context {
    playing: boolean;
    paused: boolean;
    loop: "Queue" | "Track" | "OFF";
    time: String;
    volume: number;
}
interface Player_Switch {
    op: "ready" | "playerUpdate" | "stats" | "event";
    type: "TrackStartEvent" | "TrackEndEvent" | "TrackExceptionEvent" | "TrackStuckEvent" | "WebSocketClosedEvent";
    guildId?: string;
}
export declare interface Player {
    on(eventName: "raw", listener: (payload: Player_Switch) => void): this;
    on(eventName: string | symbol, listener: (...args: any[]) => void): this;
}
export declare class Player extends EventEmitter {
    readonly Node: Node;
    readonly Queue: Queue;
    _PlayerStatus: any;
    discordSettings: _Player_discord_params;
    playerContext: _Player_context;
    get manager(): import("./Manager.Controller").Manager;
    constructor(Node: Node, Options: _Player_discord_params);
    private WebSocketClosedEvent;
    private TrackStuckEvent;
    private TrackExceptionEvent;
    private TrackEndEvent;
    private TrackStartEvent;
    restUpdate(options: any): Promise<import("axios").AxiosResponse<any, any> | undefined>;
    connect(payload: any): Promise<import("axios").AxiosResponse<any, any> | undefined>;
    play(track?: any): Promise<import("axios").AxiosResponse<any, any> | undefined>;
    pause(pause?: boolean): Promise<import("axios").AxiosResponse<any, any> | undefined>;
    setVolume(volume: number): Promise<import("axios").AxiosResponse<any, any> | undefined>;
}
export {};

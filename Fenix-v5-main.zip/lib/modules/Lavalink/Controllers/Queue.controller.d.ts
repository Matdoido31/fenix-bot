export declare class Queue {
    tracks: any;
    oldTracks: any;
    get empty(): boolean;
    get first(): any;
    add(prop: any | any[], requester?: any, playlist?: any): Promise<{
        sendEmit: boolean;
        eventName: string;
        trackAdd: any[];
    }>;
    shift(): any;
    shuffle(): any;
    clear(): any;
}

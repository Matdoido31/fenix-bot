/// <reference types="node" />
import { EventEmitter } from "@fenixdbp/eventemitter";
import { Node } from "./Node.Controller";
import { Player } from "./Player.Controller";
interface _Manager_Params {
    version: "v3" | "v4" | string;
    client: any;
}
interface _wss_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
    userId: string;
    Shards?: number;
    LavaName?: string;
}
interface _Manager_Nodes_Params {
    host: string;
    password: string;
    secure: boolean;
    port: number;
}
interface _Player_discord_params {
    guild: any;
    voiceChannel: any;
    textChannel: any;
    voiceState?: any;
    options: {
        selfMute: boolean;
        selfDeaf: boolean;
    };
}
export declare class Manager extends EventEmitter {
    private readonly _nodes;
    private managerSettings;
    client: any;
    user: any | undefined;
    readonly version: string;
    players: Map<String, Player>;
    nodes: Map<string, Node>;
    get idealNode(): Node;
    get Rest(): import("./Rest.Controller").Rest | undefined;
    constructor(Nodes: _Manager_Nodes_Params[], options: _Manager_Params);
    Infinity(user?: any): void;
    createNode(options: _wss_server_params): Node;
    createPlayer(_Node: Node, options: _Player_discord_params): void | Player;
    joinVoice(options: _Player_discord_params): Promise<void | Player>;
    _attemptConnection(guildID: String): Promise<boolean>;
    packetUpdate(packet: any): any;
    voiceServerUpdate(data: any): Promise<boolean>;
    voiceStateUpdate(data: any): any;
    send(packet: any): any;
    sendWS(guild: string, channel: string, { selfmute, selfdeaf }: {
        selfmute: boolean;
        selfdeaf: boolean;
    }): any;
}
export {};

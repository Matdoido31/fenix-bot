import { http_server } from "../Connections/http.server";
interface _http_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
}
export declare class Rest {
    sessionID: any;
    readonly http_server: http_server;
    constructor(sessionId: String, Options: _http_server_params);
    destroyPlayer(guildId: String): Promise<import("axios").AxiosResponse<any, any>>;
    updatePlayer(guildId: string, data: any): Promise<import("axios").AxiosResponse<any, any>>;
    trackLoad(search: String): Promise<import("axios").AxiosResponse<any, any>>;
}
export {};

/// <reference types="node" />
import { EventEmitter } from "@fenixdbp/eventemitter";
interface _wss_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
    userId: string;
    Shards?: number;
    LavaName?: string;
}
interface Player_Switch {
    op: "ready" | "playerUpdate" | "stats" | "event";
    type: "TrackStartEvent" | "TrackEndEvent" | "TrackExceptionEvent" | "TrackStuckEvent" | "WebSocketClosedEvent";
    guildId: string;
}
export declare interface wss_server {
    on(eventName: "raw", listener: (payload: Player_Switch) => void): this;
}
export declare class wss_server extends EventEmitter {
    private client;
    private readonly privacidade;
    constructor(options: _wss_server_params);
    connect(): void;
    destroy(): void;
    private wssParams;
}
export {};

import { Manager } from "./Controllers/Manager.Controller";
import { Node } from "./Controllers/Node.Controller";
import { Player } from "./Controllers/Player.Controller";
import { Queue } from "./Controllers/Queue.controller";
import { Rest } from "./Controllers/Rest.Controller";

export = { Manager, Node, Player, Queue, Rest };
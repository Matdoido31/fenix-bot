interface _wss_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
    userId: string;
    Shards?: number;
    LavaName?: string;
}
export declare function getInvalidServerParams(obj: _wss_server_params): Error | false;
export {};

interface _http_server_params {
    host: string;
    port: number;
    password: string;
    protocolo: string;
    version: string;
}
export declare function getInvalidServerParams(obj: _http_server_params): Error | false;
export {};

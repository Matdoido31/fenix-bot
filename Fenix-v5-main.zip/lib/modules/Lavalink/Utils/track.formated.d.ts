export declare const trackFormated: (prop: any, requester: any, playlist: any) => any;

const { PrismaClient } = require('@prisma/client');
const dummytest = require("./dummy/dummy.json")
const dummyEntries = Object.entries(dummytest);
const dummyEntriesNumberKeys = dummyEntries.map(final => {
    return final;
});
const dummyFinal = new Map(dummyEntriesNumberKeys);
module.exports = {
    prisma: new PrismaClient(),
    dummy: dummyFinal
}
const { resolve } = require("path");
const _Partials = Object.keys(Discord.Partials).filter(key => typeof Discord.Partials[key] === "number");

class Startbot {

    constructor(){
        this._client = new Discord.Collection();
        this._LoadFiles = require("../../../lib/helpers/loadFiles");
    };


    async startall(protocol){
        switch(protocol) {
            case 0: Logger.log("warn", "desativado rapa.") // db.dummy.forEach((value, key, map) => ((key != "users") && this.start(protocol, { key: key, ...value })))
                break;
            default: (await db.prisma.client.findMany()).forEach(value => this.start(protocol, { key: value.DiscordBotId , ...value }))  
                break; 
        };
    };
    
    start(protocol, base = null){
        if(typeof base === "object" && base?.key) {
            return this.ready(base);
        };

        if(!protocol || !base ) return new Error("...");

        switch(protocol) {
            case 0: Logger.log("warn", "desativado rapa.") // db.dummy.forEach((value, key) => (value.id == base && key != "users") && this.start(protocol, { key: key, ...value }));
                break;
            default: db.prisma.client.findUnique({ where: { DiscordBotId: base } }).then((_) => _.forEach(value => this.start({ key: value.id , ...value })));  
                break; 
        };
    };
           
    async ready(basefile){
        let nclient = new Discord.Client({ intents: 3276799, partials: _Partials });
        nclient.commands = new Discord.Collection();
        nclient.transport = new Discord.Collection();
        nclient.help = new Discord.Collection();
        nclient.prefixallowrandom = ""
        nclient.token = basefile.DiscordBotToken;
        
        if (this._client.has(basefile.key)) nclient.destroy() && (nclient = null);
        else ((await nclient.login()) && this._client.set(basefile.key, nclient));
        
        this._LoadFiles(nclient, { path: resolve(process.cwd(), "./lib/modules/vendor"), folders: ["events", "commands"] });
        return;
    };

};

module.exports = new Startbot();
class PokeInfo {

    _infos = {};

    constructor(){
    	this._axios = require("axios")
    }
    api(pokemon){
       return this._axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemon}/`, {
        }).then (async (res) => {
        
            let Informacoes = {
                data: null,
                Tipos: "",
                Habilidades: ""
            };

            let d = 0;

            res.data.types.forEach(async element => { Informacoes.Tipos += `**${element.type.name[0].toUpperCase() + element.type.name.substring(1)}** ` });
            await res.data.abilities.forEach(async i => {
                const data = (await this._axios.get(`${i.ability.url}`).then((res) => res.data))
                const descrição = data.effect_entries.filter(i => i.language.name === ("en" || "pt-br"))[0];
                Informacoes.Habilidades += `**${i.ability.name[0].toUpperCase() + i.ability.name.substring(1)}** -\n${descrição?.short_effect || descrição?.effect}\n\n`;
                if(data.effect_entries.length === d || data.effect_entries.length > 1 ) {
                    this._infos = {
                        data: res.data,
                        NúmeronaPokédex: res.data.id,
                        Tipos: Informacoes.Tipos,
                        Habilidades: Informacoes.Habilidades 
                    }
            }else d++
        })

            return true
        })
        .catch((err) => { return false })
    }
}

module.exports =  PokeInfo
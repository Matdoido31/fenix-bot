class Status {
    constructor(){
    	this._axios = require("axios")
        this._fs = require("fs")
        this._axios.defaults.validateStatus = (status) => {
            return status < 500;
        };
    }
    api(){
       return this._axios.get(`https://discordstatus.com/api/v2/summary.json`).then ((res) => {
			return res.data
        });
    }
}
module.exports = new Status()
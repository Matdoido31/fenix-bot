class Process {
    constructor(){
        this._callhandler = require("./handlers/startbots")
        this._status = false
        this._config = {
            
        }
    }
    emit(process){
        switch (process) {
            case 0:
                /* desligar tudo */
                this._status = false
                this.error(0)
            break;
        
            default:
                /* ligar o bot */
                this._status = true
                Logger.log("CHANGE", `Fenix Core ${adminconfig.version} Iniciado com sucesso`)
                this.callhandler()
                this.error()
            break;
        }
    }
    error(protocol){
        switch (protocol) {
            case 0:
                Logger.log("WARN", "AUTODESTRUIÇÃO")
                process.exit(0)
            break;
        
            default:
                process.on('unhandledRejection', error => {
                    console.log(error)
                    Logger.log("WARN", error)
                });
            break;
        }
    }
    callhandler(){
        this._callhandler.startall(1)
    }
}

module.exports = new Process()